import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appImageLoader]'
})
export class ImageLoaderDirective {
  @HostListener('click') mouseenter() {
    console.log('enter')
  }

  constructor() { }

}